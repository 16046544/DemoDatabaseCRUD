package sg.edu.rp.c346.colorlist;

/**
 * Created by 16046544 on 24/7/2017.
 */

public class Color {
    private String Color;

    public Color(String color) {
        Color = color;
    }

    public String getColor() {
        return Color;
    }

    public void setColor(String color) {
        Color = color;
    }
}
