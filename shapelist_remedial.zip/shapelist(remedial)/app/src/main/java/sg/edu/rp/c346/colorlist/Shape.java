package sg.edu.rp.c346.colorlist;

/**
 * Created by 16046544 on 24/7/2017.
 */

public class Shape {
    private String Shape;

    public Shape(String shape) {
        Shape = shape;
    }

    public String getShape() {
        return Shape;
    }

    public void setShape(String shape) {
        Shape = shape;
    }
}
